module.exports = {
    get authors() {
        return require('./authors');
    }
};
