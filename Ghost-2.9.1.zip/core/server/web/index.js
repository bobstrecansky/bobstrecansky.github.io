module.exports = {
    get shared() {
        return require('./shared');
    }
};
