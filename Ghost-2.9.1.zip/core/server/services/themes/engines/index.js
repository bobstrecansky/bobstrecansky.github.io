module.exports = {
    get create() {
        return require('./create');
    }
};
