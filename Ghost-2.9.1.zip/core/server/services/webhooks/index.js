module.exports = {
    get listen() {
        return require('./listen');
    },

    get trigger() {
        return require('./trigger');
    }
};
